import{G as r}from"./index-7d8ae6af.js";function e(){function n(){return r.get("/guardian/childs")}function o(t){return r.get("/guardian/dashboard?user_id="+t)}return{home:o,childs:n}}export{e as u};
